//baca semua komponen yang dibutuhkan
var conf = require("./conf");
var frameModule = require('ui/frame');
var timerModule = require("timer");
var Model = require("./all-model");
var ClassModel = new Model([]);
var context;

//membuat fungsi getlist untuk menampilkan data
function getList() {
    ClassModel.empty();
    ClassModel.getList().then(function (result) {
        context.set("items", result.data);
    });
}

//yang dijalankan ketika halaman dibuka
exports.onLoaded = function (args) {
    var page = args.object;
    context = ClassModel;
    timerModule.setTimeout(function () {
        getList();
    }, conf.timeloader);
    page.bindingContext = context;
};
//ketika tombol add data dijalankan akan memanggil module add pada index.php
exports.addContact = function (args) {
    timerModule.setTimeout(function () {
        let navOption = {
            moduleName: "add",
            animated: true,
            transition: {
                duration: conf.transduration,
                curve: conf.curve
            }
        };
        frameModule.topmost().navigate(navOption);//memindahkan halaman dengan navbar option
    }, conf.timeloader);
}
//ketika list diklik akan menjalankan fungsi editcontact kemudian akan memanggil fungsi edit pada index.php
exports.editContact = function (args) {
    timerModule.setTimeout(function () {
        let selected = args.view.bindingContext;
        let navOption = {
            moduleName: "edit",
            context: { data: selected },
            animated: true,
            transition: {
                duration: conf.transduration,
                curve: conf.curve
            }
        };
        frameModule.topmost().navigate(navOption);
    }, conf.timeloader);
}
