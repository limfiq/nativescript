var observableModule = require("tns-core-modules/data/observable");

function HomeViewModel() {
  var viewModel = observableModule.fromObject({

  });

  return viewModel;
}

module.exports = HomeViewModel;
