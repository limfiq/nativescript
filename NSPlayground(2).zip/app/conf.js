module.exports = {
    domain: "http://192.168.14.70/nativescript/index.php",
    //sesuaikan dengan ip ketika cek ipconfig nativescript adalah folder di htdocs 
    timeloader: 100,
    transduration: 200,
    curve: "linear"
};
