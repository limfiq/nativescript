var conf = require("./conf");
var ObservableArrayModule = require("data/observable-array").ObservableArray;
var httpModule = require("http");

//fungsi membuat model data yang dikirim ke back-end
function MyModel(items) {
    var viewModel = new ObservableArrayModule(items);

    //model untuk menampilkan seluruh data
    viewModel.getList = function () {
        return httpModule.request({
            url: conf.domain + '?action=list', //<=aksi list diambil dari backend pada switch di index.php
            method: "GET", //metode yang digunakan
            headers: { "Content-Type": "application/json" } //dikirim dalam bentuk json
        }).then(function (response) { //parsing json
            let result = response.content.toJSON();
            return result;
        }, function (e) {
            console.log("Error occurred " + e);
        });
    };

    //model menambahkan data
    viewModel.addData = function (data) {
        return httpModule.request({
            url: conf.domain + '?action=add',
            method: "POST",
            headers: { "Content-Type": "application/json" },
            content: JSON.stringify(data)
        }).then(function (response) {
            return response.content.toJSON();
        }, function (e) {
            console.log("Error occurred " + e);
        });
    };
    //Model edit data
    viewModel.editData = function (data) {
        return httpModule.request({
            url: conf.domain + '?action=edit',
            method: "POST",
            headers: { "Content-Type": "application/json" },
            content: JSON.stringify(data)
        }).then(function (response) {
            return response.content.toJSON();
        }, function (e) {
            console.log("Error occurred " + e);
        });
    };
    //model hapus data
    viewModel.deleteData = function (data) {
        return httpModule.request({
            url: conf.domain + '?action=delete',
            method: "POST",
            headers: { "Content-Type": "application/json" },
            content: JSON.stringify(data)
        }).then(function (response) {
            return response.content.toJSON();
        }, function (e) {
            console.log("Error occurred " + e);
        });
    };

    //model data masih kosong
    viewModel.empty = function () {
        while (viewModel.length) {
            viewModel.pop();
        }
    };

    return viewModel;
}
//mengekspor data agar dapat dibaca diseluruh projek 
module.exports = MyModel;
